testsdi: source code and sample editor in Visual C++ 6.0
TestUAS: source code and sample editor in delphi 6.0
uas.exe: binary installation package of UAS
uas.ico: recommended toolbar image for UAS in client application
interface.htm: interfacing guide for programmers

