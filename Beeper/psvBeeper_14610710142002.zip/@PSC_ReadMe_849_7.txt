Title: psvBeeper 2.0
Description: psvBeeper library for Delphi 5, 6 and 7 contains components for playing different types of sound:
TpsvBeeper to play system sounds
TpsvWavSound to play wav files
TpsvMidiSound to play midi files
This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=849&lngWId=7

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
