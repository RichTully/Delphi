KN_Help.knt     - KeyNote Help file in KNT format, by Nathan Sendhil
KN_Handbook.knt - a collection of KeyNote-related material, by Nathan Sendhil 

(from http://www.tranglos.com/free/keynote_addons.html)