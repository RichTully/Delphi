File listing explanation

ushell.ico: icon image for UAS
TestUAS.dpr: Editor Example project for integration with UAS
UAS.pas: delphi unit file of the interfacing source code



