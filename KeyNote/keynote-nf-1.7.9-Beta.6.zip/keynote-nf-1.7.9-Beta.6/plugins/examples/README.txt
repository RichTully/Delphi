- kn_funckey.knl 
  Allows you to customize function keys. Alt, Shift+Alt and Ctrl+Alt function key combinations can be assigned to
  plugins, macros, styles, templates and fonts.

- kn_calendar.knl
  Displays a simple calendar and allows you to insert selected date in active note.


More plugins and additional material (sample files, help files, etc.) are available from the Add-ons page of 
original KeyNote, in the following page:

http://www.tranglos.com/free/keynote_addons.html

It also includes 'Plugin development kit' (kntplugins-dev.zip), with documentation and example source code for 
those interested in writing plugins for KeyNote.